EMAIL_ADDRESS = "여러분의 메일주소를 입력하세요" # 주소
EMAIL_PASSWORD = "여러분의 비밀번호를 입력하세요" # 앱 비밀번호